"""Minesword Search Engine package."""

__version__ = "1.0.0"
